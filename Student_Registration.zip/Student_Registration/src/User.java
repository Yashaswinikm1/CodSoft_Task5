public class User
{
    public String name;
    public String email;
    public  String phone;
    public String address;
    public String password;
}
